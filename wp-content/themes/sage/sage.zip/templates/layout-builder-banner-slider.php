<!-- start of hero -->
<section class="hero hero-slider-wrapper hero-slider-s1">
    <div class="hero-slider">
        <div class="slide row">
            <img src="http://res.cloudinary.com/hrscywv4p/image/upload/c_limit,fl_lossy,h_1500,w_2000,f_auto,q_auto/v1/792431/IMG_0551_copy_2_wgzye1.jpg" alt class="slider-bg">
            <div class="container">
                <div class="row">
                    <div class="col col-lg-8 col-lg-offset-2 col-md-10 col-md-offset-1 slide-caption">
                        <h1>Change Someone's Life with the gift of learning</h1>
                        <a href="#" class="btn btn-primary">Give Now</a>
                    </div>
                </div>
            </div>
        </div>
        <div class="slide row">
            <img src="http://themexriver.com/charity-world/multi-page/charityworld/images/slider/slide-2.jpg" alt class="slider-bg">
            <div class="container" style="z-index:999999;">
                <div class="row">
                    <div class="col col-lg-8 col-lg-offset-2 col-md-10 col-md-offset-1 slide-caption">
                        <h1>Don’t let this beauty disappear. Fight with us.</h1>
                        <a href="#" class="btn btn-primary">Give Now</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- end of hero slider -->

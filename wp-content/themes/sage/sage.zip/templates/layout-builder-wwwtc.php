<div class="to-change-section">
    <div class="section-title">
        <h2>What we want to change</h2>
    </div>

    <div class="to-change-holder clearfix">
        <ul>
            <li>
                <a href="#" style="background-image: url('https://kungfuture.org/media/conflict.jpg');">
                    <h3>Disaster Relief</h3>
                </a>
            </li>
            <li>
                <a href="#" style="background-image: url('http://themekalia.com/wp/humanwelfare/wp-content/uploads/2016/12/featured-image-14-795x399.jpg');">
                    <h3>Medical</h3>
                </a>
            </li>
            <li>
                <a href="#" style="background-image: url('http://themekalia.com/wp/humanwelfare/wp-content/uploads/2016/12/featured-image-10.jpg');">
                    <h3>Education</h3>
                </a>
            </li>
            <li>
                <a href="#" style="background-image: url('http://themekalia.com/wp/humanwelfare/wp-content/uploads/2016/12/featured-image-14-795x399.jpg');">
                    <h3>Child Trafficking</h3>
                </a>
            </li>
        </ul>
    </div>
</div>
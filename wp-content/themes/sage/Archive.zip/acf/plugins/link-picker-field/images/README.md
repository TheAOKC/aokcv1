# Images directory

Use this directory to store images.

This directory can be removed if not used.

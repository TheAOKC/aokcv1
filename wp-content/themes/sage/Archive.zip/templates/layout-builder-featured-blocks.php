<!-- start charity-categories-section -->
<section class="charity-categories-section featued-blocks">
    <div class="container">
        <div class="section-title">
            <h3>1.3B People live inextreme poeverty, <br>Less than $1.24 a Day. Our Mission is to change that, and here's how</h3>
        </div> <!-- end section-title -->

        <div class="row charity-categories-section-grids">
            <div class="col col-md-4 col-sm-6">
                <div class="grid">
                    <div class="icon">
                        <img src="<?php echo get_template_directory_uri(); ?>/assets/images/icons/aokc-icon-1.svg" alt="">
                    </div>
                    <div class="info">
                        <h3><a href="#">We Shine a light into the dark</a></h3>
                        <p>Icididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam</p>
                        <a href="#" class="details">Learn More</a>
                    </div>
                </div>
            </div>
            <div class="col col-md-4 col-sm-6">
                <div class="grid">
                    <div class="icon">
                        <img src="<?php echo get_template_directory_uri(); ?>/assets/images/icons/aokc-icon-2.svg" alt="">
                    </div>
                    <div class="info">
                        <h3><a href="#">Our actions are free of financial motivation</a></h3>
                        <p>Icididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam</p>
                        <a href="#" class="details">Learn More</a>
                    </div>
                </div>
            </div>
            <div class="col col-md-4 col-sm-6">
                <div class="grid">
                    <div class="icon">
                        <img src="<?php echo get_template_directory_uri(); ?>/assets/images/icons/aokc-icon-3.svg" alt="">
                    </div>
                    <div class="info">
                        <h3><a href="#">We empower opeole to stand in their own power</a></h3>
                        <p>Icididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam</p>
                        <a href="#" class="details">Learn More</a>
                    </div>
                </div>
            </div>
        </div> <!-- end row -->
        <div class="row section-footer-title">
            <div class=" section-title">
                <div class="col col-md-8 col-md-offset-2">
                    <h3>We are a for-impact organization changing things on a grassroots level in Nepal but we have big dreams.
                        Our mission is ti to transform the lives of 1M poeple in 10years.
                    </h3>
                </div>
            </div> <!-- end section-title -->
        </div> <!-- end section-title -->

    </div> <!-- end container -->
</section>
<!-- end charity-categories-section -->